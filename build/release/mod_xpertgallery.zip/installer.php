<?php
/**
 * @package   Xpert Installer
 * @version   1.0
 * @author    Parvez Akther http://www.themexpert.com
 * @copyright Copyright (C) 20010 - 2012 Parvez Akther
 * @license   GNU/GPL v3 or later license
 */

die();