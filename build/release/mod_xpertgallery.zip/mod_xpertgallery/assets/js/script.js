/**
 * @package Xpert Gallery
 * @version 
 * @author ThemeXpert http://www.themexpert.com
 * @copyright Copyright (C) 2009 - 2011 ThemeXpert
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */

jQuery(document).ready(function($)
{
    // init Isotope
    var $container = $('.tx-gallery-container').isotope({
        itemSelector: '.tx-gallery-container li',
        layoutMode: 'fitRows',
        getSortData: {
          title: '.tx-gallery-title',
          date: '.tx-gallery-date'
        }
    });

    // bind filter button click
    $('.tx-gallery-filters').on( 'click', 'li', function() {
        var filterValue = $( this ).attr('data-filter');
        $container.isotope({ filter: filterValue });
        // Assign active class
        $(this).siblings().removeClass('active');
        $(this).addClass('active');
    });

     // bind sort button click
    $('.tx-gallery-sort').on( 'click', 'li', function() {
        var sortValue = $(this).attr('data-sort');
        $container.isotope({ sortBy: sortValue });
        // Assign active class
        $(this).siblings().removeClass('active');
        $(this).addClass('active');
    });

    //Magnific popup options
     $('.tx-gallery-image a, .tx-gallery-image-preview').magnificPopup({type:'image'});
     $('.tx-gallery-image-link').magnificPopup({ 
        type: 'ajax',
        overflowY: 'scroll'
    });
});